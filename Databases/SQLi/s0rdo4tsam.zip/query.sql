/*
  Select the brand, model and price from cars

  In our WHERE clause, we'll match against a placeholder value:
    <<BRAND>>
*/